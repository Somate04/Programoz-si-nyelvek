// pstack.h

#ifndef PSTACK_H
#define PSTACK_H

#include <vector>
#include <functional>

template <typename T, typename P = int, typename Compare = std::less<P>>
class priority_stack
{
private:
    struct Element
    {
        T value;
        P priority;
    };

    std::vector<Element> elements;
    Compare comparator;

public:
    void push(const T& value, const P& priority)
    {
        Element element{value, priority};
        elements.push_back(element);
        std::sort(elements.begin(), elements.end(), [this](const Element& a, const Element& b) {
            return comparator(a.priority, b.priority);
        });
    }

    void pop()
    {
        if (!elements.empty())
            elements.pop_back();
    }

    const T& top() const
    {
        if (!elements.empty())
            return elements.back().value;
        throw std::out_of_range("Stack is empty");
    }

    size_t size() const
    {
        return elements.size();
    }
};

#endif // PSTACK_H
