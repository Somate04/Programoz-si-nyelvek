#ifndef ARVIOPS__H
#define ARVIOPS__H

#include <algorithm>

template <typename T>
class array_view_operations
{
    T *data;
    size_t size;

    public:
    array_view_operations(T *array, size_t s) : data(array), size(s){}

    void reverse()
    {
        std::reverse(data, data + size);
    }

    void reset()
    {
        std::reverse(data, data + size);
    }
    void shift(int n)
    {
        std::rotate(data, data + n, data + size);
    }
};

#endif