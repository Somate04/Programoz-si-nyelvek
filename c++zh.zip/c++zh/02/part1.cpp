#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

int main()
{
    ifstream file("input.txt");
    string line;
    unsigned int sum = 0;
    string dl = ";";
    size_t pos;
    string token;
    vector<int> cubes;
    vector<vector<int>> game;
    vector<vector<vector<int>>> games;
    getline(file, line, '\n');
    int step;
    bool b;
    for(int j = 0; j < 100; j++)
    {
        step = 0;
        b = false;
        game.clear();
        while((pos = line.find(dl)) != string::npos)
        {
            cubes.clear();
            token = line.substr(0, pos); //leválasztja a stringet az elválaszóig
            for(int i = 0; i < token.length(); i++)
            {
                string s;
                if(token[i] == ':')
                {
                    int g = token[i-1]-'0';
                    if(isdigit(token[i-2])){
                        g += (token[i-2]-'0')*10;
                        if(isdigit(token[i-3])){
                            g += (token[i-3]-'0')*100;
                        }

                    }
                    cubes.push_back(g);
                    cubes.push_back(token[i+2]-'0');
                }
                if(step != 0 && !b)
                {
                    cubes.push_back(token[1]-'0');
                    b = true;
                }
                if(token[i] == ',')
                {
                    int a = token[i+2]-'0';
                    if(isdigit(token[i+3]))
                    {
                        a *= 10;
                        a += token[i+3]-'0';
                    }
                    cubes.push_back(a);
                }

            }
            game.push_back(cubes);
            line.erase(0, pos + 1); //kitörli a tokent, hogy a következő stringet kivehesse
            step++;
            b = false;
        }
        //cout << line << endl; //utolsó elválasztó utáni rész
        games.push_back(game);
        getline(file, line, '\n');
    }
    
    
    cout << sum << endl;
}
//12 red, 13, green, 14 blue